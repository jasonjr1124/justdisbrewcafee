import { Star } from "lucide-react";

const reviews = [
  {
    name: "Jennifer West",
    text: "Lively place in the courthouse. Friendly and quick service. Great coffee. I'm so glad I stopped by.",
    rating: 5,
  },
  {
    name: "Sheila Chiasson",
    text: "I love love love the fraps and smoothies here. And the price is very fair.",
    rating: 5,
  },
  {
    name: "Kenneth Bennett",
    text: "Hands down better than Starbucks, with more flavors than any brew shop.",
    rating: 5,
  },
  {
    name: "Leah Martin",
    text: "Amazing atmosphere and the best lattes in town. Will definitely be coming back!",
    rating: 5,
  },
];

const Reviews = () => {
  return (
    <section id="reviews" className="py-20 bg-card">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <div className="flex items-center justify-center gap-1 mb-4">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="w-5 h-5 fill-gold text-gold" />
            ))}
          </div>
          <h2 className="text-4xl md:text-5xl font-serif text-foreground mb-2">
            5.0 on Google
          </h2>
          <p className="text-muted-foreground font-sans">What our customers say</p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 max-w-5xl mx-auto">
          {reviews.map((r) => (
            <div
              key={r.name}
              className="bg-background rounded-lg p-6 shadow-sm border border-border"
            >
              <div className="flex gap-0.5 mb-3">
                {[...Array(r.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-gold text-gold" />
                ))}
              </div>
              <p className="text-sm text-muted-foreground font-sans mb-4 leading-relaxed">
                "{r.text}"
              </p>
              <p className="font-sans font-medium text-foreground text-sm">{r.name}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Reviews;
