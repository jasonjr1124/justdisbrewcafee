import { useState } from "react";
import { Coffee, Menu, X } from "lucide-react";

const Navbar = () => {
  const [open, setOpen] = useState(false);

  const links = [
    { label: "Menu", href: "#menu" },
    { label: "Reviews", href: "#reviews" },
    { label: "About", href: "#about" },
    { label: "Contact", href: "#contact" },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-espresso/90 backdrop-blur-sm">
      <div className="container mx-auto flex items-center justify-between py-4 px-6">
        <a href="#" className="flex items-center gap-2 text-primary-foreground">
          <Coffee className="w-6 h-6 text-gold" />
          <span className="font-serif text-xl">JustDisBrew</span>
        </a>
        <div className="hidden md:flex items-center gap-8">
          {links.map((l) => (
            <a
              key={l.label}
              href={l.href}
              className="text-latte text-sm tracking-wide hover:text-gold transition-colors font-sans"
            >
              {l.label}
            </a>
          ))}
        </div>
        <button
          className="md:hidden text-latte"
          onClick={() => setOpen(!open)}
          aria-label="Toggle menu"
        >
          {open ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>
      {open && (
        <div className="md:hidden bg-espresso border-t border-warm-brown px-6 pb-4">
          {links.map((l) => (
            <a
              key={l.label}
              href={l.href}
              onClick={() => setOpen(false)}
              className="block py-3 text-latte text-sm tracking-wide hover:text-gold transition-colors font-sans"
            >
              {l.label}
            </a>
          ))}
        </div>
      )}
    </nav>
  );
};

export default Navbar;
