import { Coffee, UtensilsCrossed } from "lucide-react";

const snacks = [
  { name: "Nachos (Regular)", price: "$6.00", desc: "Served with cheese & peppers" },
  { name: "Nachos (Loaded)", price: "$6.50", desc: "Fully loaded with toppings" },
  { name: "Swamp Nachos*", price: "$8.00", desc: "Served Thursdays & Fridays during summer and Lent" },
  { name: "Homemade Chili (4 oz)", price: "$3.00", desc: "Rich & hearty homemade chili" },
  { name: "Regular Cheese (4 oz)", price: "$3.00", desc: "Classic melted cheese dip" },
  { name: "Swamp Cheese (4 oz)", price: "$5.00", desc: "Spicy signature cheese dip" },
];

const sandwiches = [
  { name: "Breakfast Sandwich", price: "$3.00", desc: "Sausage, egg & cheese on croissant; double sausage biscuit; maple sausage, egg & cheese" },
  { name: "Regular Sandwich", price: "$4.00", desc: "Chicken salad, ham & cheese, turkey & Swiss, roast beef, cheeseburgers, White Castle burgers, BBQ rib" },
  { name: "Italian Sub", price: "$4.00", desc: "Classic Italian sub, pre-packaged" },
];

const saladsAndSides = [
  { name: "Chicken Caesar Salad", price: "$6.00", desc: "Fresh romaine with grilled chicken" },
  { name: "Chicken Santa Fe Salad", price: "$6.00", desc: "Southwest-style with grilled chicken" },
  { name: "Nuts & Cheese Tray", price: "$2.25", desc: "Perfect snack combo" },
  { name: "Hard-Boiled Eggs (2-pack)", price: "$2.25", desc: "Protein-packed snack" },
];

const drinks = [
  { name: "House Drip Coffee", price: "$3.50", desc: "Smooth, full-bodied blend" },
  { name: "Espresso", price: "$3.00", desc: "Rich double shot" },
  { name: "Cappuccino", price: "$5.00", desc: "Espresso with steamed milk foam" },
  { name: "Café Latte", price: "$5.50", desc: "Espresso with velvety steamed milk" },
  { name: "Caramel Frappe", price: "$6.50", desc: "Blended with caramel & cream" },
  { name: "Mocha Frappe", price: "$6.50", desc: "Chocolate espresso blend" },
  { name: "Berry Smoothie", price: "$6.00", desc: "Mixed berries & yogurt" },
  { name: "Mango Smoothie", price: "$6.00", desc: "Tropical mango delight" },
  { name: "Honey Lavender Latte", price: "$6.50", desc: "Floral & sweet" },
  { name: "Brown Sugar Oat Latte", price: "$6.00", desc: "Rich & creamy oat milk" },
  { name: "Iced Vanilla Cold Brew", price: "$5.50", desc: "Slow-steeped & smooth" },
  { name: "Chai Latte", price: "$5.50", desc: "Spiced & comforting" },
];

const menuCategories = [
  { title: "Snacks", items: snacks, icon: UtensilsCrossed },
  { title: "Sandwiches", items: sandwiches, icon: UtensilsCrossed },
  { title: "Salads & Sides", items: saladsAndSides, icon: UtensilsCrossed },
  { title: "Drinks", items: drinks, icon: Coffee },
];

const MenuSection = () => {
  return (
    <section id="menu" className="py-20 bg-background">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <Coffee className="w-8 h-8 text-gold mx-auto mb-4" />
          <h2 className="text-4xl md:text-5xl font-serif text-foreground mb-4">Our Menu</h2>
          <p className="text-muted-foreground font-sans max-w-md mx-auto">
            Crafted with care — from hearty snacks to handcrafted drinks, there's something for everyone.
          </p>
          <p className="text-sm text-muted-foreground font-sans mt-3 italic">
            Follow us on Instagram <span className="text-gold">@justdisbrewcafe</span> for seasonal menu items and updates.
          </p>
        </div>
        <div className="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
          {menuCategories.map((cat) => (
            <div key={cat.title}>
              <div className="flex items-center gap-3 mb-6">
                <cat.icon className="w-5 h-5 text-gold" />
                <h3 className="text-2xl font-serif text-foreground">{cat.title}</h3>
              </div>
              <div className="space-y-5">
                {cat.items.map((item) => (
                  <div key={item.name} className="flex justify-between items-start gap-4">
                    <div>
                      <p className="font-sans font-medium text-foreground">{item.name}</p>
                      <p className="text-sm text-muted-foreground font-sans">{item.desc}</p>
                    </div>
                    <span className="font-sans font-semibold text-gold whitespace-nowrap">
                      {item.price}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default MenuSection;
