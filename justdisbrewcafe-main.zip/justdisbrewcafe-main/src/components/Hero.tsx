import heroImage from "@/assets/hero-coffee.jpg";

const Hero = () => {
  return (
    <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden">
      <img
        src={heroImage}
        alt="Artisanal coffee at JustDisBrew Cafe"
        className="absolute inset-0 w-full h-full object-cover"
        width={1920}
        height={1080}
      />
      <div className="absolute inset-0 bg-espresso/60" />
      <div className="relative z-10 text-center px-6 max-w-3xl mx-auto">
        <p className="text-gold font-sans text-sm tracking-[0.3em] uppercase mb-4">
          Gretna, Louisiana
        </p>
        <h1 className="text-5xl md:text-7xl font-serif text-primary-foreground mb-6 leading-tight">
          JustDisBrew Cafe
        </h1>
        <p className="text-lg md:text-xl text-latte font-light mb-8 max-w-xl mx-auto">
          Handcrafted coffee, fraps & smoothies — brewed with love, served with a smile.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <a
            href="#menu"
            className="px-8 py-3 bg-gold text-accent-foreground font-sans font-medium rounded-sm hover:opacity-90 transition-opacity tracking-wide"
          >
            View Our Menu
          </a>
          <a
            href="#about"
            className="px-8 py-3 border border-latte text-latte font-sans font-medium rounded-sm hover:bg-latte/10 transition-colors tracking-wide"
          >
            Visit Us
          </a>
        </div>
      </div>
    </section>
  );
};

export default Hero;
