import { Coffee } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-espresso py-10">
      <div className="container mx-auto px-6 text-center">
        <div className="flex items-center justify-center gap-2 mb-4">
          <Coffee className="w-5 h-5 text-gold" />
          <span className="font-serif text-lg text-primary-foreground">JustDisBrew Cafe</span>
        </div>
        <p className="text-sm text-latte/60 font-sans">
          © {new Date().getFullYear()} JustDisBrew Cafe. All rights reserved.
        </p>
      </div>
    </footer>
  );
};

export default Footer;
