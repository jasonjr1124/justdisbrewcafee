import { MapPin, Clock, Phone } from "lucide-react";

const About = () => {
  return (
    <section id="about" className="py-20 bg-background">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-serif text-foreground mb-6">Visit Us</h2>
          <p className="text-muted-foreground font-sans max-w-lg mx-auto mb-12 leading-relaxed">
            Located in the heart of Gretna, JustDisBrew Cafe is your neighborhood spot for
            handcrafted coffee and genuine Southern hospitality.
          </p>
          <div className="grid sm:grid-cols-3 gap-8" id="contact">
            <div className="flex flex-col items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-gold/10 flex items-center justify-center">
                <MapPin className="w-5 h-5 text-gold" />
              </div>
              <h3 className="font-serif text-lg text-foreground">Location</h3>
              <p className="text-sm text-muted-foreground font-sans">
                200 Derbigny St.<br />Gretna, LA
              </p>
            </div>
            <div className="flex flex-col items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-gold/10 flex items-center justify-center">
                <Clock className="w-5 h-5 text-gold" />
              </div>
              <h3 className="font-serif text-lg text-foreground">Hours</h3>
              <p className="text-sm text-muted-foreground font-sans">
                Mon – Fri: 7am – 5pm<br />Sat: 8am – 3pm<br />Sun: Closed
              </p>
            </div>
            <div className="flex flex-col items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-gold/10 flex items-center justify-center">
                <Phone className="w-5 h-5 text-gold" />
              </div>
              <h3 className="font-serif text-lg text-foreground">Contact</h3>
              <p className="text-sm text-muted-foreground font-sans">
                <a href="tel:504-648-7705" className="text-gold hover:underline">504-648-7705</a><br />
                <a href="mailto:justdisbrew@gmail.com" className="text-gold hover:underline">justdisbrew@gmail.com</a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
